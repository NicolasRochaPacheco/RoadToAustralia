# RoadToAustralia
Uniandes RoboCup 2019 Team repository. We'd like to be in RoboCup 2019 with Pepper.
